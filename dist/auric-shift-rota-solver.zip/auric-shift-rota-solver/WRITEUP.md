# Architecture under a fixed, weak model

**Constraint extraction is model-based.** The model turns each line of notes into
one constraint or into nothing. Nothing in the answering pipeline pattern-matches
the notes; everything after extraction is symbolic and exact.

| budget | macro | n | range | u / a / i |
|---|---|---|---|---|
| **1×** | **0.481 ± 0.040** | 15 | 0.417–0.533 | 0.45 / 0.44 / 0.55 |
| **3×** | **0.504 ± 0.043** | 9 | 0.450–0.583 | 0.50 / 0.47 / 0.55 |
| **10×** | **0.504 ± 0.034** | 9 | 0.450–0.550 | 0.52 / 0.45 / 0.60 |
| no formal layer | **0.000** | 9 | — | 0.00 / 0.00 / 0.00 |

Mean ± population SD over the runs in the `n` column, 33 in total; the last
row is the brief's 0.0% reproduced. **All three budgets sit within half a
standard deviation of each other.** 1× has n=15 because `-vote`/`-repair` at
one call are the *same code path* as `full`. Tables:
[ABLATION.md](ABLATION.md).

## 1. Characterising the model first

**It cannot hold the problem.** One-shot it declares `unique` for everything and
scores 0.0; it put two people on one block and emitted three incompatible JSON
shapes for the station field. It has no representation of ambiguity or
contradiction at all, so it is never asked to count, compare or decide. **It is
good at one thing:** translating a single line, especially spotting one that says
nothing — 28 of 28 padding lines.

**Its errors are asymmetric.** A regex reference parser (100% of 1,137 visible
lines) gave per-line ground truth: precision per *emitted* code is 87% overall but
spans `BETWEEN` 97% down to `BLOCK` 71%. The signature error is **resolving a
relative statement into an absolute one**, and an invented placement kills most of
an item's 720 worlds where a wrong relative one kills few. Three of four distractor
families are free to over-read: thwarted wishes read as negatives are **64/64
entailed**, unresolved questions 31/31, but past-tense station history **0/25**,
always false. One dangerous over-reading, so the rules lead with it — worth 0.133.

**I verified the target semantics before building.** That parser plus the solver,
counting only present-tense definite statements, scores **macro 1.0000** on all 60
items — so every remaining point is an extraction problem.

## 2. Why each component exists

**The spine.** One call translates the lines; the solver enumerates all 720
worlds. One world is `unique`, two or more `ambiguous` (all returned), none
`inconsistent`. The citation is a minimal unsatisfiable subset found by deletion
— *definitionally* the scorer's rule. Citing every constraining line instead
scores **0.00** on all 20 inconsistent items (`mus`, −0.167).

**Two free repairs, worth more than either paid one at 1x.** `calib` (−0.022): every
real conflicting set has ≥3 statements — **none of size 2** — so a two-statement
core is provably not a conflict the notes contain and is wrong whichever kind the
item is. Nothing is lost by disbelieving one, and the precision table says which.
`softneg` (−0.033) is the mirror: a line read as inert naming one person and
one clock time is tried as a negative block claim, kept only if it removes worlds
and leaves one. They are **additive** (−0.083). Both reverse sign at 3x, where removing
either *gains* ~0.07 — just outside the table's measured null of 0.045 — so
they earn their place at 1x and plausibly interfere with the repair loop above
it.

**`repair`.** The world count proves extraction error with no key: `>4` re-reads
only the lines read as inert, `0` re-reads *exactly the core*. Impossible answers
fall from **11 at 1× to 1 at 3×**. **Reply format** was a component in
disguise: dictating the reply's first characters took coverage **68% → 89%**.

## 3. What I built and then removed

**Two aggregation designs.** Per-line vote merging made the curve non-monotone
(10× fell to 0.400) by dropping constraints only a minority of passes found,
dissolving correctly-detected contradictions; verdict-majority replaced it and
was also wrong. Replaying one three-pass log with the extraction fixed,
**every way of combining three extractions lost to the best single one**
(0.383–0.517 vs passes of 0.533 / 0.400 / 0.550): the errors are systematic, so
averaging reinforces them. What works is *selection* — keep the first
candidate not provably wrong (0.567).

**Restatement agreement, removed** after measuring that the scorer trap it
guarded cannot fire. **`strict`** measures at zero and is kept anyway: refusing
to repair a hallucinated name is a property I want held out.

## 4. Where it breaks, and why the curve is flat

Five extractions of all 60 items, every line-judgement bucketed:
**79.5% right in all five, 4.0% wrong in all five identically** — only ~16% is
reachable by resampling, and that 4.0% is mostly *silent* under-extraction (30 of
46 are real constraints read as nothing). An item needs its whole reading right, so
**only 28 of 60 items have no permanently-wrong line (46.7%)** — the ceiling
resampling reaches, and the system already sits on it at one call.

**Under-extraction on unique items** is the largest bucket (9 of 20 declared
ambiguous at 1×): nothing separates "genuinely ambiguous" from "one constraint
short", so no trigger fires.
Two ablation cells that are *identical code paths* to the full system differ
from it by 0.044 and 0.022, so that is what zero effect measures here: only the
formal layer, `mus` and the prompt rules clear it.

## 5. If the notes were written by people

**Survives.** The formal layer never touches text. The few-shot example uses
*paraphrases absent from `items.json`* — "starts the moment Erin finishes", not the
visible set's "directly after" — so the extractor sees the semantic category, not
the template, and repair triggers are properties of a solution count. **Degrades gracefully:** what the closed
vocabulary cannot express goes inert, so the item over-declares ambiguous —
failing honestly and *visibly*.

**Breaks.** Real notes conflict *in degree*, and the architecture rests on hedges
carrying full force, which the brief guarantees and reality does not. `softneg`
rests on a measured property of this generator — no inert line mentions a clock
time — that one realistic sentence would break, and people contradict themselves in
pairs, killing `MIN_CORE = 3`. The symbolic half transfers; the two free components
producing most of the gain are the two most exposed.

## 6. With a month

**Attack extraction recall, not the budget** — that 4% is the binding constraint
and the oracle ceiling above it is 1.00; a two-stage call classifying each line
before emitting a code targets the silent drops and the dimension confusions.
**Fit the trust order** per code and context, making the drop a likelihood
comparison rather than a size threshold. **Make ambiguity a question for the
model**, which nothing currently asks. And **generate my own held-out
set** from a disjoint phrasing pool, to *measure* transfer.
